# Totaphysics AI Backend — Vercel API (v4 with Streaming)

This repository powers the **Totaphysics AI Portal** using Vercel serverless functions + OpenAI.

Now includes **streaming** so answers appear word-by-word, like ChatGPT.

---

## 🚀 Setup

### 1. Clone this repo
```bash
git clone https://github.com/YOUR_USERNAME/totaphysics-ai-backend.git
cd totaphysics-ai-backend
```

### 2. Deploy to Vercel
- Go to [Vercel Dashboard](https://vercel.com/dashboard)
- Click **New Project → Import GitHub Repo**
- Select `totaphysics-ai-backend`

### 3. Add Environment Variables
In **Vercel → Settings → Environment Variables**:

- `OPENAI_API_KEY = your_api_key_here`

Scope: Production + Preview

### 4. Deploy
Click **Deploy**.

---

## ✅ Test Endpoint
Visit:
```
https://ai.iyaboko.org/api/chat
```
You should see:
```
{"error":"Only POST allowed"}
```

Send POST requests with JSON:
```json
{ "message": "Tell me about energy" }
```

Expected → Totaphysical AI response (streamed).

---

## 🧪 Test Frontend Page
You can connect this to a simple Squarespace code block:

```html
<script>
async function askTotaphysics() {
  const input = document.getElementById("totaphysics-input").value;
  const responseBox = document.getElementById("totaphysics-response");
  responseBox.innerHTML = "⏳ Thinking...";

  const res = await fetch("https://ai.iyaboko.org/api/chat", {
    method: "POST",
    body: JSON.stringify({ message: input })
  });

  const reader = res.body.getReader();
  const decoder = new TextDecoder("utf-8");
  responseBox.innerHTML = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = decoder.decode(value, { stream: true });
    responseBox.innerHTML += chunk;
    responseBox.scrollTop = responseBox.scrollHeight;
  }
}
</script>
```

---

🌌 Built for the **Iyaboko Totaphysics Institute**.
