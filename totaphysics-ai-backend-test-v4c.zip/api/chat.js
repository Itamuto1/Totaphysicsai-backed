
// api/chat.js
import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Only POST allowed" });
  }

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
    const message = body?.message || "Hello Scholar";

    // Streaming headers
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const stream = await client.chat.completions.create({
      model: "gpt-4o-mini",
      stream: true,
      messages: [
        {
          role: "system",
          content: `
You are Totaphysics AI, created for the Iyaboko Totaphysics Institute.
- Always answer using Totaphysical logic.
- Use Iyaboko Laws, Akiyakiyakabo, and constants (Kaboo, Gotomai, Imoumikapo, Totakabo-Dakii).
- Never use metaphysics, multiverse, divine will, or free will.
- Replace "return" with "continuity" and "reform".
          `,
        },
        { role: "user", content: message },
      ],
    });

    for await (const chunk of stream) {
      const token = chunk.choices[0]?.delta?.content || "";
      if (token) {
        res.write(token);
      }
    }
    res.end();
  } catch (err) {
    console.error("Stream error:", err);
    res.write("⚠️ Error: " + (err.message || "Unknown issue"));
    res.end();
  }
}
