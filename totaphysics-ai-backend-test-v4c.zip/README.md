# Totaphysics AI Backend — Vercel API (v4c with Styled Test Page)

This repository powers the **Totaphysics AI Portal** using Vercel serverless functions + OpenAI.

Includes:
- **Streaming** so answers appear word-by-word, like ChatGPT.
- **test.html** simple version
- **test-styled.html** styled version with glowing Totaphysical theme

---

## 🚀 Setup

1. Deploy to Vercel
2. Add environment variable:
   - `OPENAI_API_KEY` = your_api_key_here
3. Redeploy

---

## ✅ Test

Visit:
```
https://YOUR-VERCEL-URL.vercel.app/test.html
```
or
```
https://YOUR-VERCEL-URL.vercel.app/test-styled.html
```

Type a message → you should see Totaphysics AI respond in real-time.

---

🌌 Built for the **Iyaboko Totaphysics Institute**.
